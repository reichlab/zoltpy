# zoltpy
A python module that interfaces with Zoltar https://github.com/reichlab/forecast-repository

# requirements
- [pipenv](https://pipenv.readthedocs.io/en/latest/) for managing packages - see Pipfile
- requests
- [click](https://click.palletsprojects.com/en/7.x/) - for the demo application's handling of args
